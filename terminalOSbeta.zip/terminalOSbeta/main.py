from time import sleep
import os
import random
from words import word_list

# Enter Login Info #

print('Welcome')
sleep(0.1)
print('To')
sleep(0.1)
print('Terminal')
sleep(0.1)
print('OS\n\n\n')
sleep(5)
os.system('clear')
print("Loading: [◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻] 0%")
sleep(0.2)
os.system('clear')
print("Loading: [◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻] 3%")
sleep(0.2)
os.system('clear')
print("Loading: [◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻] 5%")
sleep(1)
os.system('clear')
print("Loading: [◼◼◼◼◼◻◻◻◻◻◻◻◻◻◻◻◻◻◻◻] 27%")
sleep(4)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◻◻◻◻◻◻◻◻] 64%")
sleep(2)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◻◻◻◻] 82%")
sleep(0.4)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◻] 95%")
sleep(0.6)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◻] 96%")
sleep(3)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◻] 98%")
sleep(8)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◻] 99%")
sleep(1)
os.system('clear')
print("Loading: [◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼◼] 100%")
sleep(5)
print('Loading Complete...')
sleep(0.1)
print('Please Wait...')
sleep(10)
os.system('clear')

print('TerminalOS\n')
sleep(0.3)
print("Create A Username | Will Not Save")
name = input('> ')
os.system('clear')
print ("\a")
print('Welcome to TerminalOS,', name)
sleep(2)
os.system('clear')
while True:
    cmd = input('Enter A Command\n> ')
    if cmd == ('1'):
        print('Not ready...')
    elif cmd == ('3'):
        def get_word():
            word = random.choice(word_list)
            return word.upper()


        def play(word):
            word_completion = "_" * len(word)
            guessed = False
            guessed_letters = []
            guessed_words = []
            tries = 6
            print("Hangman!")
            print(display_hangman(tries))
            print(word_completion)
            print("\n")
            while not guessed and tries > 0:
                guess = input("Please guess a letter or word: ").upper()
                if len(guess) == 1 and guess.isalpha():
                    if guess in guessed_letters:
                        print("You already guessed the letter", guess)
                    elif guess not in word:
                        print(guess, "is not in the word.")
                        tries -= 1
                        guessed_letters.append(guess)
                    else:
                        print("Good job,", guess, "is in the word.")
                        guessed_letters.append(guess)
                        word_as_list = list(word_completion)
                        indices = [i for i, letter in enumerate(word) if letter == guess]
                        for index in indices:
                            word_as_list[index] = guess
                        word_completion = "".join(word_as_list)
                        if "_" not in word_completion:
                            guessed = True
                elif len(guess) == len(word) and guess.isalpha():
                    if guess in guessed_words:
                        print("You already guessed the word", guess)
                    elif guess != word:
                        print(guess, "isn't correct.")
                        tries -= 1
                        guessed_words.append(guess)
                    else:
                        guessed = True
                        word_completion = word
                else:
                    print("Not a valid guess.")
                print(display_hangman(tries))
                print(word_completion)
                print("\n")
            if guessed:
                print("You guess the word. You win!")
            else:
                print("Sorry, you ran out of tries. The word was " + word + ".")


        def display_hangman(tries):
            stages = [  # final state: head, torso, both arms, and both legs
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / \\
                   -
                """,
                # head, torso, both arms, and one leg
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |     / 
                   -
                """,
                # head, torso, and both arms
                """
                   --------
                   |      |
                   |      O
                   |     \\|/
                   |      |
                   |      
                   -
                """,
                # head, torso, and one arm
                """
                   --------
                   |      |
                   |      O
                   |     \\|
                   |      |
                   |     
                   -
                """,
                # head and torso
                """
                   --------
                   |      |
                   |      O
                   |      |
                   |      |
                   |     
                   -
                """,
                # head
                """
                   --------
                   |      |
                   |      O
                   |    
                   |      
                   |     
                   -
                """,
                # initial empty state
                """
                   --------
                   |      |
                   |      
                   |    
                   |      
                   |     
                   -
                """
            ]
            return stages[tries]


        def main():
            word = get_word()
            play(word)
            while input("Play Again? (Y/clear) ").upper() == "Y":
                word = get_word()
                play(word)

        if __name__ == "__main__":
            main()
